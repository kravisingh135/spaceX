import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardViewComponent } from './components/dashboard-view/dashboard-view.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { TestPageComponent } from './components/test-page/test-page.component';


const routes: Routes = [
  {path: 'dashboard', component: DashboardViewComponent},
  {path: '',   redirectTo: '/dashboard', pathMatch: 'full'},
  {path: 'sample-page',  component: TestPageComponent},
  {path: '**',  component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
