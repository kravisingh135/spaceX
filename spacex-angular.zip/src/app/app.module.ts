import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { TreeViewMenuComponent } from './shared/tree-view-menu/tree-view-menu.component';
import { HamburgerMenuComponent } from './shared/hamburger-menu/hamburger-menu.component';
import { DashboardViewComponent } from './components/dashboard-view/dashboard-view.component';
import { NgxBootstrapTreeviewModule } from 'ngx-bootstrap-treeview';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ChartsModule } from 'ng2-charts';
import { LaunchChartComponent } from './components/launch-chart/launch-chart.component';
import { LaunchTimelineComponent } from './components/launch-timeline/launch-timeline.component';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { TestPageComponent } from './components/test-page/test-page.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TreeViewMenuComponent,
    HamburgerMenuComponent,
    DashboardViewComponent,
    LaunchChartComponent,
    LaunchTimelineComponent,
    PageNotFoundComponent,
    TestPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxBootstrapTreeviewModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ChartsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
// required for AOT compilation
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
