import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SpacexDataService } from 'src/app/service/spacex-data.service';

export interface Launches {
  flight_number: number,
}

@Component({
  selector: 'app-dashboard-view',
  templateUrl: './dashboard-view.component.html',
  styleUrls: ['./dashboard-view.component.less']
})
export class DashboardViewComponent implements OnInit {

  upcomingLaunches: Array<string>;
  pastLaunches: Array<string>;

  constructor(private spacexDataService: SpacexDataService, translate: TranslateService) {
    translate.use('en');
  }

  ngOnInit(): void {
    this.spacexDataService.upcomingLaunches().subscribe((res) => {
      const missionName = [];
      for (var key in res) {
        if (res.hasOwnProperty(key)) {
          missionName.push(res[key].mission_name);
        }
      }
      this.upcomingLaunches = missionName;
    });

    this.spacexDataService.pastLaunches().subscribe((res) => {
      const missionName = [];
      for (var key in res) {
        if (res.hasOwnProperty(key)) {
          missionName.push(res[key].mission_name);
        }
      }
      this.pastLaunches = missionName;
    });
  }
}
