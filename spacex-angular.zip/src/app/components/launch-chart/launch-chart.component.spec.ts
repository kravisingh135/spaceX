import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaunchChartComponent } from './launch-chart.component';

describe('LaunchChartComponent', () => {
  let component: LaunchChartComponent;
  let fixture: ComponentFixture<LaunchChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaunchChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaunchChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
