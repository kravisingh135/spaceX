import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ChartOptions } from 'chart.js';
import { Color } from 'ng2-charts';
import { SpacexDataService } from 'src/app/service/spacex-data.service';

@Component({
  selector: 'app-launch-chart',
  templateUrl: './launch-chart.component.html',
  styleUrls: ['./launch-chart.component.less']
})
export class LaunchChartComponent implements OnInit {

  allLaunches: Array<number>;

  barChartOptions: ChartOptions;
  barChartColors: Color[];
  barChartLabels: Array<string>;
  barChartType: string;
  barChartData: any[];

  constructor(private spacexDataService: SpacexDataService, translate: TranslateService) {
    translate.use('en');
  }

  ngOnInit(): void {
    this.spacexDataService.allLaunches().subscribe((res) => {
      const launchYear = [];
      for (const key in res) {
        if (res.hasOwnProperty(key)) {
          launchYear.push(res[key].launch_year);
        }
      }
      this.allLaunches = launchYear;
      const yearlyLaunchCount = this.allLaunches.reduce((prev, next) => {
        if(next in prev){
          prev[next]++;
        }else{
          prev[next] = 1;
        }
        return prev;
      },{});

      const barLabel = [];
      const barData = [];
      for(const [key, val] of Object.entries(yearlyLaunchCount)) {
        barLabel.push(key);
        barData.push(val);
      }
      this.barChartLabels = barLabel;
      this.barChartData = [{
        data: barData
      }];
    });

    this.barChartOptions = {
      responsive: true,
      legend: { display: false },
      scales: {
        xAxes: [
          {
            gridLines: {
              display: false,
            }
          }
        ]
      }
    };

    this.barChartColors = [{ backgroundColor: "#1976d2" }];
    this.barChartType = "bar";
  }

}
