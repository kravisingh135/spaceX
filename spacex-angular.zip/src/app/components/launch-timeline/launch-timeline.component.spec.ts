import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaunchTimelineComponent } from './launch-timeline.component';

describe('LaunchTimelineComponent', () => {
  let component: LaunchTimelineComponent;
  let fixture: ComponentFixture<LaunchTimelineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaunchTimelineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaunchTimelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
