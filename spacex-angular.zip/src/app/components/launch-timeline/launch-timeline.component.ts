import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SpacexDataService } from 'src/app/service/spacex-data.service';

@Component({
  selector: 'app-launch-timeline',
  templateUrl: './launch-timeline.component.html',
  styleUrls: ['./launch-timeline.component.less']
})
export class LaunchTimelineComponent implements OnInit {

  timeLineData: Array<Date>;

  constructor(private spacexDataService: SpacexDataService, translate: TranslateService) {
    translate.use('en');
  }

  ngOnInit(): void {
    this.spacexDataService.allLaunches().subscribe((res) => {
      const launchDate = [];
      for (var key in res) {
        if (res.hasOwnProperty(key)) {
          launchDate.push(res[key].launch_date_utc);
        }
      }
      this.timeLineData = launchDate;
    });
  }

}
