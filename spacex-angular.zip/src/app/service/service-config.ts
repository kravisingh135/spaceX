export const baseApiUrl = '/dev';
