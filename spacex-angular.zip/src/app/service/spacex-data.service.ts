import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseApiUrl } from './service-config';

@Injectable({
  providedIn: 'root'
})
export class SpacexDataService {

  baseURL = 'https://api.spacexdata.com/v3';

  constructor(private http: HttpClient) { }

  upcomingLaunches() {
    return this.http.get(`${this.baseURL}/launches/upcoming?limit=10`);
  }

  pastLaunches() {
    return this.http.get(`${this.baseURL}/launches/past?limit=15`);
  }

  allLaunches() {
    return this.http.get(`${this.baseURL}/launches`);
  }


}
