import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-hamburger-menu',
  templateUrl: './hamburger-menu.component.html',
  styleUrls: ['./hamburger-menu.component.less']
})
export class HamburgerMenuComponent implements OnInit {

  constructor(translate: TranslateService) {
    translate.use('en');
  }

  ngOnInit(): void {
  }

}
