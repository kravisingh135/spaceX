import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tree-view-menu',
  templateUrl: './tree-view-menu.component.html',
  styleUrls: ['./tree-view-menu.component.less']
})
export class TreeViewMenuComponent implements OnInit {
  menuList: any;
  constructor() { }

  ngOnInit(): void {
    this.menuList = [
      {
          label: 'Spacex Docs',
          children: [
              {
                  label: 'Capsules',
                  children: [
                      {
                          label: 'All Capsules',
                      },
                      {
                          label: 'One Capsule',
                      },
                      {
                          label: 'Upcoming Capsules',
                      },
                      {
                          label: 'Past Capsules',
                      }
                  ]
              },
              {
                  label: 'Cores',
                  children: [
                      {
                          label: 'All Cores',
                      },
                      {
                          label: 'One Cores',
                      },
                      {
                          label: 'Upcoming Cores',
                      },
                      {
                          label: 'Past Cores',
                      }
                  ]
              },
              {
                label: 'Dragons',
                children: [
                    {
                        label: 'All Dragons',
                    },
                    {
                        label: 'One Dragons'
                    }
                ]
              },
              {
                label: 'History',
                children: [
                    {
                        label: 'All Historical Events',
                    },
                    {
                        label: 'One Historical Event'
                    }
                ]
              }
            ]
        }
    ]
  }

}
